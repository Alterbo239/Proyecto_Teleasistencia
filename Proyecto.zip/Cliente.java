import java.util.Date;
import java.util.List;

public class Cliente {
private String nombre;
private String direccion;
    
/* Declaro un campo privado llamado familiares que es una lista de objetos de tipo Familiar.
Utilizando (List<Familiar>) para especificar el tipo de elementos que contendrá la lista. */
private List<Familiar> familiares;

public Cliente() {
       
}
public String getNombre() {
    return nombre;
}

public void setNombre(String nombre) {
    this.nombre = nombre;
}

public String getDireccion() {
    return direccion;
}

public void setDireccion(String direccion) {
    this.direccion = direccion;
}

public List<Familiar> getFamiliares() {
    return familiares;
}

public void setFamiliares(List<Familiar> familiares) {
    this.familiares = familiares;
}
}


public class Alarma {
    private Date fechaHora;
    private String motivo;
    private Empleado empleadoAtendido;
    private String tareaRealizada;
    private Date fechaFinalizacion;

    public Alarma() {
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public Empleado getEmpleadoAtendido() {
        return empleadoAtendio;
    }

    public void setEmpleadoAtendido(Empleado empleadoAtendido) {
        this.empleadoAtendido = empleadoAtendido;
    }

    public String getTareaRealizada() {
        return tareaRealizada;
    }

    public void setTareaRealizada(String tareaRealizada) {
        this.tareaRealizada = tareaRealizada;
    }

    public Date getFechaFinalizacion() {
        return fechaFinalizacion;
    }

    public void setFechaFinalizacion(Date fechaFinalizacion) {
        this.fechaFinalizacion = fechaFinalizacion;
    }
}
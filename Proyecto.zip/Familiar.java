public class Familiar {
private String nombre;
private String numeroTelefono;

public Familiar() {
}

public String getNombre() {
    return nombre;
}

public void setNombre(String nombre) {
    this.nombre = nombre;
}

public String getNumeroTelefono() {
    return numeroTelefono;
}

public void setNumeroTelefono(String numeroTelefono) {
    this.numeroTelefono = numeroTelefono;
}
}

public class ServicioaDomicilio {
private String tipoServicio;

public ServicioDomicilio() {
}

public String getTipoServicio() {
    return tipoServicio;
}

public void setTipoServicio(String tipoServicio) {
    this.tipoServicio = tipoServicio;
}
}
public class Tarea {
private String descripcion;

public Tarea() {
}

public String getDescripcion() {
    return descripcion;
}

public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
}
public static void main(String[] args) {
Tarea tarea = new Tarea();
tarea.setDescripcion("Realizar una tarea ");
System.out.println("Descripción de la tarea: " + tarea.getDescripcion());
}
}